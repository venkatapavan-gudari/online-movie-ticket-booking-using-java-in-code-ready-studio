package backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String email = request.getParameter("email");
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");

        String errorMessage = null;

        // Input validation patterns
        String namePattern = "^[a-zA-Z]+$";
        String emailPattern = "^[a-zA-Z0-9._%+-]+@gmail\\.com$";
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\W).+$";

        // Validate input
        if (firstName == null || !firstName.matches(namePattern)) {
            errorMessage = "Incorrect first name. Only characters are allowed.";
        } else if (lastName == null || !lastName.matches(namePattern)) {
            errorMessage = "Incorrect last name. Only characters are allowed.";
        } else if (email == null || !email.matches(emailPattern)) {
            errorMessage = "Incorrect email. Email should be in the format @gmail.com.";
        } else if (userName == null || userName.isEmpty()) {
            errorMessage = "User name is required.";
        } else if (password == null || !password.matches(passwordPattern)) {
            errorMessage = "Incorrect password format. Password should contain at least one uppercase letter, one lowercase letter, and one symbol.";
        }

        if (errorMessage == null) {
            try {
                // Database connection details
                String dbURL = "jdbc:mysql://localhost:3306/project";
                String dbUser = "root";
                String dbPassword = "3040";

                // Load the JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the connection
                Connection connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);

                // SQL query to insert user data
                String sql = "INSERT INTO admin (first_name, last_name, email, username, password) VALUES (?, ?, ?, ?, ?)";

                // Create a statement
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, firstName);
                statement.setString(2, lastName);
                statement.setString(3, email);
                statement.setString(4, userName);
                statement.setString(5, password);

                // Execute the statement
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    response.sendRedirect("login.jsp");
                } else {
                    errorMessage = "Registration failed. Please try again.";
                }

                // Close the resources
                statement.close();
                connection.close();
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                errorMessage = "Error occurred while registering user: " + e.getMessage();
            }
        }

        if (errorMessage != null) {
            request.setAttribute("errorMessage", errorMessage);
            request.getRequestDispatcher("registration.jsp").forward(request, response);
        }
    }
}
