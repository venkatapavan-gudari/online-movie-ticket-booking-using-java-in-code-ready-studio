package backend;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private static final String URL = "jdbc:mysql://localhost:3306/project";
    private static final String USER = "root";
    private static final String PASSWORD = "3040";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movie = request.getParameter("movie");
        String dates = request.getParameter("dates");
        String timings = request.getParameter("timings");
        String theaters = request.getParameter("theaters");
        String ratings = request.getParameter("ratings");

        try (Connection connection = getConnection()) {
            String sql = "INSERT INTO bookings (movie, dates, timings, theaters, ratings) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, movie);
            statement.setString(2, dates);
            statement.setString(3, timings);
            statement.setString(4, theaters);
            statement.setString(5, ratings);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                request.setAttribute("movie", movie);
                request.setAttribute("dates", dates);
                request.setAttribute("timings", timings);
                request.setAttribute("theaters", theaters);
                request.setAttribute("ratings", ratings);
                
            } else {
                response.getWriter().write("Failed to insert booking data.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Database connection problem: " + e.getMessage());
        }
    }

    private Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
